package add

func Add(a int, b int) (num int) {
	return a + b
}
