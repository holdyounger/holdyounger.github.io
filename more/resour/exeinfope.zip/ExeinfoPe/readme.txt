
 ==============================================================

          Exeinfo PE v0.0.4.3 - 960 + 49 signatures

           with partial support for 64 bit PE files

           Ext_detector.dll - ver.0.3.8.2

 ==============================================================


included : 
  
   userDB.txt        - 4512 Signatures in list  ( fixed ver.)
   ( Exeinfo Pe check only EP offset bytes , max 4700 signatures ,
     hex bytes E*,A* not supported - Errors hidden )
   
   Languages : neutral v042 , China Big5 / China Simplified / Rus v0.0.4.1


plugins :

  none / compatible with Peid.exe


  added :


 - new signatures , old signatures updated ( newer version update )
   added : Radstudio v10.1 ESD ( C++ Builder 10.1 Berlin Starter - 2015 )
 - About picture changed on Main Form
 - file .pdb searcher added
 - console added : "/lol:'
 - DFM scan fixed
 - Exe PE ripper added support for - Base64 encoded files
 - GUI fixed for Win 10
 - many small changes ...




Exeinfo NON GUI - Console Mode info 

if you need change log file "!ExEinfo-Multiscan.log" to your path/file

try : exeinfope.exe FileName* /s /log:C:\MyLogFile.txt
  For long file path/names 
try : exeinfope.exe FileName* /s /log:"C:\My Dir 1 2 3\LogFile.txt"


 more info 

 try : exeinfope.exe /?




   A.S.L (c) www.exeinfo.xn.pl - 2016.08.11


